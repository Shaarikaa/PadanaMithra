import { useEffect, useRef, useState, type FormEvent } from 'react';
import { Send, Volume2, Square, Sparkles, Bot, User as UserIcon } from 'lucide-react';
import { AppShell } from '@/components/AppShell';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { cn } from '@/lib/utils';
import type { ChatMessage } from '@/lib/types';
import { useApp } from '@/lib/AppContext';
import { getChaptersForSubject } from '@/lib/curriculum';
// To Do: Replace with real Gemini API Key here — wire generateTutorReply to the Gemini API.
import { generateTutorReply } from '@/lib/mockData';

const LANGUAGES = [
  { value: 'en-US', label: 'English' },
  { value: 'ml-IN', label: 'Malayalam' },
  { value: 'hi-IN', label: 'Hindi' },
];

const SUGGESTED = ['Explain Motion', 'What is Ohms Law', 'Newton laws of motion', 'Photosynthesis'];

export function AITutorPage() {
  const { profile } = useApp();
  const tutorContext = profile ? {
    name: profile.fullName,
    classLevel: profile.classLevel,
    board: profile.board,
    subject: profile.currentSubject,
    chapter: profile.currentChapter,
    topic: profile.currentTopic,
  } : undefined;

  const welcomeMsg = profile?.currentSubject && profile?.currentChapter
    ? `Hi ${profile.fullName.split(' ')[0]}! I am your AI Tutor. I see you're studying ${profile.currentSubject} — ${profile.currentChapter}${profile.currentTopic ? ` (${profile.currentTopic})` : ''}. Ask me anything about it, or any other topic!`
    : "Hi! I am your AI Tutor. Ask me about any topic or chapter — for example Explain Motion or What is Ohms Law?";

  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: 'welcome',
      role: 'bot',
      content: welcomeMsg,
      timestamp: Date.now(),
    },
  ]);
  const [input, setInput] = useState('');
  const [thinking, setThinking] = useState(false);
  const [language, setLanguage] = useState('en-US');
  const [speaking, setSpeaking] = useState(false);
  const [speakingId, setSpeakingId] = useState<string | null>(null);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: 'smooth' });
  }, [messages, thinking]);

  useEffect(() => {
    return () => {
      if (typeof window !== 'undefined' && window.speechSynthesis) {
        window.speechSynthesis.cancel();
      }
    };
  }, []);

  const handleSend = (e?: FormEvent) => {
    e?.preventDefault();
    const text = input.trim();
    if (!text || thinking) return;

    const userMsg: ChatMessage = {
      id: `u-${Date.now()}`,
      role: 'user',
      content: text,
      timestamp: Date.now(),
    };
    setMessages((m) => [...m, userMsg]);
    setInput('');
    setThinking(true);

    setTimeout(() => {
      const reply = generateTutorReply(text, tutorContext);
      const botMsg: ChatMessage = {
        id: `b-${Date.now()}`,
        role: 'bot',
        content: reply,
        timestamp: Date.now(),
      };
      setMessages((m) => [...m, botMsg]);
      setThinking(false);
    }, 700 + Math.random() * 500);
  };

  const handleListen = (content: string, id: string) => {
    if (typeof window === 'undefined' || !window.speechSynthesis) return;

    if (speaking && speakingId === id) {
      window.speechSynthesis.cancel();
      setSpeaking(false);
      setSpeakingId(null);
      return;
    }

    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(content);
    utterance.lang = language;
    utterance.onend = () => {
      setSpeaking(false);
      setSpeakingId(null);
    };
    utterance.onerror = () => {
      setSpeaking(false);
      setSpeakingId(null);
    };
    window.speechSynthesis.speak(utterance);
    setSpeaking(true);
    setSpeakingId(id);
  };

  const stopSpeaking = () => {
    if (typeof window !== 'undefined' && window.speechSynthesis) {
      window.speechSynthesis.cancel();
    }
    setSpeaking(false);
    setSpeakingId(null);
  };

  const profileChapters = profile?.currentSubject ? getChaptersForSubject('class-9', profile.currentSubject) : [];
  const allChapters = profileChapters.length > 0 ? profileChapters.map(c => c.name) : ['Motion', 'Laws of Motion', 'Chemical Reactions', 'Trigonometry', 'Cell', 'Life Processes'];

  return (
    <AppShell
      title="AI Tutor Chatbot"
      subtitle="Ask about any topic or chapter. Tap Listen to hear the answer aloud."
    >
      <div className="grid gap-6 lg:grid-cols-[1fr_280px]">
        <div className="flex h-[calc(100vh-280px)] min-h-[420px] flex-col overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm">
          <div className="flex items-center justify-between gap-3 border-b border-slate-100 px-4 py-3">
            <div className="flex items-center gap-2 text-sm font-medium text-slate-700">
              <Sparkles className="h-4 w-4 text-indigo-600" />
              Voice language
            </div>
            <div className="flex items-center gap-2">
              <Select value={language} onValueChange={setLanguage}>
                <SelectTrigger className="h-9 w-32">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {LANGUAGES.map((l) => (
                    <SelectItem key={l.value} value={l.value}>
                      {l.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              {speaking && (
                <Button size="sm" variant="outline" onClick={stopSpeaking} className="h-9 border-rose-200 text-rose-600 hover:bg-rose-50">
                  <Square className="mr-1.5 h-3.5 w-3.5" />
                  Stop
                </Button>
              )}
            </div>
          </div>

          <ScrollArea className="flex-1 px-4" ref={scrollRef as never}>
            <div className="space-y-4 py-4">
              {messages.map((msg) => (
                <div
                  key={msg.id}
                  className={cn('flex gap-3', msg.role === 'user' ? 'flex-row-reverse' : 'flex-row')}
                >
                  <div
                    className={cn(
                      'flex h-8 w-8 shrink-0 items-center justify-center rounded-full',
                      msg.role === 'bot' ? 'bg-indigo-100 text-indigo-600' : 'bg-slate-200 text-slate-600',
                    )}
                  >
                    {msg.role === 'bot' ? <Bot className="h-4 w-4" /> : <UserIcon className="h-4 w-4" />}
                  </div>
                  <div className={cn('max-w-[80%]', msg.role === 'user' ? 'items-end' : 'items-start')}>
                    <div
                      className={cn(
                        'rounded-2xl px-4 py-2.5 text-sm leading-relaxed',
                        msg.role === 'bot'
                          ? 'rounded-tl-sm bg-slate-100 text-slate-800'
                          : 'rounded-tr-sm bg-indigo-600 text-white',
                      )}
                    >
                      {msg.content}
                    </div>
                    {msg.role === 'bot' && msg.id !== 'welcome' && (
                      <button
                        onClick={() => handleListen(msg.content, msg.id)}
                        className={cn(
                          'mt-1.5 inline-flex items-center gap-1.5 rounded-full px-2.5 py-1 text-xs font-medium transition',
                          speaking && speakingId === msg.id
                            ? 'bg-rose-100 text-rose-600'
                            : 'text-indigo-600 hover:bg-indigo-50',
                        )}
                      >
                        {speaking && speakingId === msg.id ? (
                          <>
                            <Square className="h-3 w-3" />
                            Stop
                          </>
                        ) : (
                          <>
                            <Volume2 className="h-3 w-3" />
                            Listen
                          </>
                        )}
                      </button>
                    )}
                  </div>
                </div>
              ))}

              {thinking && (
                <div className="flex gap-3">
                  <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-indigo-100 text-indigo-600">
                    <Bot className="h-4 w-4" />
                  </div>
                  <div className="rounded-2xl rounded-tl-sm bg-slate-100 px-4 py-3">
                    <div className="flex gap-1">
                      <span className="h-2 w-2 animate-bounce rounded-full bg-slate-400 [animation-delay:-0.3s]" />
                      <span className="h-2 w-2 animate-bounce rounded-full bg-slate-400 [animation-delay:-0.15s]" />
                      <span className="h-2 w-2 animate-bounce rounded-full bg-slate-400" />
                    </div>
                  </div>
                </div>
              )}
            </div>
          </ScrollArea>

          <form onSubmit={handleSend} className="border-t border-slate-100 p-3">
            <div className="flex gap-2">
              <Input
                value={input}
                onChange={(e) => setInput(e.target.value)}
                placeholder="Ask about any topic..."
                className="flex-1"
              />
              <Button type="submit" disabled={!input.trim() || thinking} className="bg-indigo-600 hover:bg-indigo-700">
                <Send className="h-4 w-4" />
              </Button>
            </div>
          </form>
        </div>

        <div className="space-y-4">
          <div className="rounded-2xl border border-slate-200 bg-white p-4 shadow-sm">
            <h3 className="text-sm font-semibold text-slate-900">Try asking</h3>
            <div className="mt-3 flex flex-wrap gap-2">
              {SUGGESTED.map((s) => (
                <button
                  key={s}
                  onClick={() => setInput(s)}
                  className="rounded-full border border-slate-200 bg-slate-50 px-3 py-1.5 text-xs font-medium text-slate-700 transition hover:border-indigo-200 hover:bg-indigo-50 hover:text-indigo-600"
                >
                  {s}
                </button>
              ))}
            </div>
          </div>

          <div className="rounded-2xl border border-slate-200 bg-white p-4 shadow-sm">
            <h3 className="text-sm font-semibold text-slate-900">Chapters available</h3>
            <p className="mt-1 text-xs text-slate-500">From the uploaded syllabus PDF</p>
            <div className="mt-3 flex flex-wrap gap-1.5">
              {allChapters.slice(0, 14).map((c) => (
                <button
                  key={c}
                  onClick={() => setInput(`Explain ${c}`)}
                  className="rounded-md bg-indigo-50 px-2 py-1 text-xs text-indigo-700 transition hover:bg-indigo-100"
                >
                  {c}
                </button>
              ))}
            </div>
          </div>

          <div className="rounded-2xl border border-amber-200 bg-amber-50/60 p-4">
            <p className="text-xs text-amber-800">
              <span className="font-semibold">Note:</span> This prototype uses mock AI responses. Connect a real Gemini API key to analyze your uploaded PDFs.
            </p>
          </div>
        </div>
      </div>
    </AppShell>
  );
}
